<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          
          <!-- search form -->
        
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            
            <li class="active treeview">
              <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              
            </li>
            
             <li class="treeview">
              <a href="">
                <i class="fa fa-angle-left pull-right"></i>
                <span>Fun Kids Clothes</span>                
              </a>     
                <ul class="treeview-menu">
                <li><a href="clothes-type.php"><i class="fa fa-circle-o"></i> Clothing Types</a></li>  
                 <li><a href="product-sizes.php"><i class="fa fa-circle-o"></i> Product Sizes</a></li>  
                  <li><a href="product-colors.php"><i class="fa fa-circle-o"></i> Product Colors</a></li>  
                <li><a href="products.php"><i class="fa fa-circle-o"></i> Products</a></li>
                
                
              </ul>
                 </li>   
            
            
                  
            
                      
                 
             
           
            
	  	
           
             
              	
	 
	 
           <li class="treeview">
              <a href="">
                <i class="fa fa-angle-left pull-right"></i>
                <span>Users</span>                
              </a>     
                <ul class="treeview-menu">
                <li><a href="users.php"><i class="fa fa-circle-o"></i> Register Users</a></li>
                <li><a href="kid-admin-user.php"><i class="fa fa-circle-o"></i> Admin Users</a></li>     
                <li class="treeview">
              <a href="contactus.php">
                <i class="fa fa-circle-o"></i>Contact Us              
              </a>
              
            </li>
              </ul>
                 </li>   
             <!--
            <li class="treeview">
              <a href="">
                <i class="fa fa-angle-left pull-right"></i>
                <span>Stories</span>                
              </a>     
                <ul class="treeview-menu">
                    <li><a href="stories.php"><i class="fa fa-circle-o"></i>Stories</a></li>
                <li><a href="story_comments.php"><i class="fa fa-circle-o"></i> Story Comments</a></li>                
              </ul>
                 </li>
              -->
             

          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>